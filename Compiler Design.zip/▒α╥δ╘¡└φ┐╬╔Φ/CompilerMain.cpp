#include <iostream>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <ctype.h>
#include <vector>
#include <algorithm> 

using namespace std;
 
///This compiler just realize the lexical analysis and parsing for a simplified Pascal.
//The analysing sample is program.txt.And the console will show the procedure of top-down method for parsing.
//If you run this cpp,you will find some chinese.
//You can translate into English according to what I give.
//ʹ�õ�1������ʽ����use No.1 production �ռ���IDƥ��ɹ�����the terminal "ID" is successfully matched 
 
 
 
enum State{s0,s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,rs,err}; //rs means restart ,err means error 
enum Edge{letter,digit,sdl,colon,eq,squotes,dot,other}; //�������ת���ı� 
void errorHandle(ofstream& ,int ,int ,int );//������ 
/* ����û�аѵ�������ʹ��ͬһ��ö�������ˣ���ʹ��string���򵥴�������token���������
   �籣����program ��token������;�Ϊstring word = "program" 
enum Kind{PROGRAM,PROCEDURE,TYPE,VAR,IF,THEN,ELSE,FI,WHILE,DO,ENDWH,
		  BEGIN,END,READ,WRITE,ARRAY,OF,RECORD,RETURN,
		  //����Ϊ������ 
		  INTEGER,CHAR,
		  //����Ϊ����
		  ID,INTC,CHARC,
		  //���ַ����ʷ���
		  PLUS,MINUS,MULTI,DIVID,LT,EQ,
		  LPARENTHESES,RPARENTHESES,LBRACKETS,RBRACKETS,DOT,SEMI,COMMA,
		  //����Ϊ���ַֽڷ�
		  ASSIGN,SQUOTES,RANGEDELIMIT
		};
		*/ 
//״̬ת������    L D SDL : =  '  .  other 
State T[11][8] = {s1,s2,s3,s4,s3,s6,s9,err,    //s0  ��ʼ״̬
				s1,s1,rs,rs,rs,rs,rs,rs,       //s1  ��ʶ��ID 
				rs,s2,rs,rs,rs,rs,rs,rs,       //s2  �޷�������INTC
				rs,rs,rs,rs,rs,rs,rs,rs,       //s3  ���ַ��ֽ��  
				err,err,err,err,s5,err,err,err,//s4 :
				rs,rs,rs,rs,rs,rs,rs,rs,       //s5   = ͣ��S5����� := ASSIGN 
				s7,s7,err,err,err,err,err,err, //s6  ' 
				err,err,err,err,err,s8,err,err,//s7 'L|D
				rs,rs,rs,rs,rs,rs,rs,rs,       //s8 'L|D'  CHARC 
				rs,rs,rs,rs,rs,rs,s10,rs,      //s9  . 
				rs,rs,rs,rs,rs,rs,rs,rs       //s10  .. �����±���޷� 
				};
//�����ֱ�
struct ReservedTable
{	
	vector<string> arryword;
	ReservedTable(); 
	bool find(string& ); 
};
ReservedTable::ReservedTable(){
	ifstream input("reserved_word.txt",ios::in);
	string reserved;
	while(input>>reserved){
		arryword.push_back(reserved);
	} 
	input.close();
}
bool ReservedTable::find(string& s){
	for(int i=0;i<arryword.size();++i){
		if(s==arryword[i]){
			return true;
		} 
	}
	return false;
} 

ReservedTable reservedtable;


ofstream SNLE;  //�����ļ���־ 
int parseline = 1;
int parselineword = 1; 

//Token����
struct Token
{
vector<string> t;
int token_id = 0;      //����token���б�� 
void push_back(string );
string getToken();
void Match(string,string); 
string getNextToken(); 
};
void Token::push_back(string s)
{
	t.push_back(s);
} 

string Token::getToken()
{
	string s = t[token_id];
	transform(s.begin(),s.end(),s.begin(),::toupper);
	while(s=="\n"){
		++parseline;
		parselineword = 1;
		s = getNextToken();
	}
	return s;
} 
string Token::getNextToken()
{
	string s = t[++token_id];
	transform(s.begin(),s.end(),s.begin(),::toupper);
	return s;
}
void Token::Match(string a,string b)
{
	if(a!=b){
		//�������� 
		errorHandle(SNLE,parseline,parselineword,1);
	}
	else{
		//ƥ�䴦�� 
		++token_id;
		++parselineword;
		cout<<"�ռ���"<<b<<"ƥ��ɹ�"<<endl;
	}
}
Token token;

const int predictNum = 104; 

//����ʽ��predict��
struct Predict
{
	vector<vector<string> >arrypred;
	Predict(); 
	Predict(ifstream&);
	void split(string& s,vector<string >& v);
	bool isGenerated(string&,int); 
 } ;
Predict::Predict(ifstream& input)
{
	//������ʽ��predict������vector<vector<string >> arrypred�У�
	//v[i][j]  i��������ʽ��� 
	char* s = new char[100];
	string line;
	for(int i=0;i<predictNum;++i){
		input.getline(s,100);
		line.assign(s,strlen(s)); 	
		arrypred.push_back( *(new vector<string >) );
		split(line,arrypred[i]); 
	} 
	/*	
	for(int i=0;i<predictNum;++i){
		for(int j=0;j<arrypred[i].size();++j){
			cout<<arrypred[i][j]<<" ";
		}
		cout<<endl;
	}
	*/
}
void Predict::split(string& s,vector<string >& v)
{
	s.erase(0,s.find_first_not_of(' '));
	s += " "; 
	int first = 0;
	int end = s.find(' ',first);
	for(int i = 0;first!=string::npos&&end!=string::npos;++i){
		v.push_back(s.substr(first,end-first));
//		cout<<v[i]<<' ';
		first = s.find_first_not_of(' ',end);
		end = s.find(' ',first);
	} 
//	cout<<endl;
}	
bool Predict::isGenerated(string& t,int num)
{
	for(int i=0;i<arrypred[num].size();++i){
		if(t==arrypred[num][i]){
			cout<<"ʹ�õ�"<<num+1<<"������ʽ"<<endl; 
			return true;
		}
	} 
	return false;
}
Edge getEdge(char&);
string toString(int num);
bool isSingleDelimit(const char&);
void scanner(ifstream& ,ofstream& );
void recurseParsing(Predict&);
void ProgramHead(Predict&);
void ProgramName(Predict&);
void DeclarePart(Predict&);
void TypeDecpart(Predict&);
void TypeDec(Predict&);
void TypeDecList(Predict&);
void TypeDecMore(Predict&);
void TypeId(Predict&);
void TypeDef(Predict&);
void BaseType(Predict&);
void StructureType(Predict&);
void ArrayType(Predict&);
void Low(Predict&);
void Top(Predict&);
void RecType(Predict&);
void FieldDecList(Predict&);
void FieldDecMore(Predict&);
void IdList(Predict&);
void IdMore(Predict&);
void VarDecpart(Predict&);
void VarDec(Predict&);
void VarDecList(Predict&);
void VarDecMore(Predict&);
void VarIdList(Predict&);
void VarIdMore(Predict&);
void ProcDecpart(Predict&);
void ProcDec(Predict&);
void ProcDecMore(Predict&);
void ProcName(Predict&);
void ParamList(Predict&);
void ParamDecList(Predict&);
void ParamMore(Predict&);
void Param(Predict&);
void FormList(Predict&);
void FidMore(Predict&);
void ProcDecPart(Predict&);
void ProcBody(Predict&);
void ProgramBody(Predict&);
void StmList(Predict&);
void StmMore(Predict&);
void Stm(Predict&);
void AssCall(Predict&);
void AssignmentRest(Predict&);
void ConditionalStm(Predict&);
void LoopStm(Predict&);
void InputStm(Predict&);
void Invar(Predict&);
void OutputStm(Predict&);
void ReturnStm(Predict&);
void CallStmRest(Predict&);
void ActParamList(Predict&);
void ActParamMore(Predict&);
void RelExp(Predict&);
void OtherRelE(Predict&);
void Exp(Predict&);
void OtherTerm(Predict&);
void Term(Predict&);
void OtherFactor(Predict&);
void Factor(Predict&);
void Variable(Predict&);
void VariMore(Predict&);
void FieldVar(Predict&);
void FieldVarMore(Predict&);
void CmpOp(Predict&);
void AddOp(Predict&);
void MultOp(Predict&);
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int main(int argc, char** argv) {
	//��Դ�����ļ�����һ����з���������Token���� 
	//�������ɱ����ֱ� 
	
	//��һ���򿪴��Դ������ļ� SNLprogram.txt �ʹ��token���ļ�������Ϣ���ļ� compile_err.txt 
	
	ifstream SNLf("program.txt",ios::in);
	if(SNLf==NULL){
		cout<<"program.txt������"<<endl;
	}
	SNLE.open("compile_err.txt",ios::out);
	ofstream tokenf("token.txt",ios::out);
	//�ڶ�����ȡԴ�����ļ��ַ���������״̬ת�������жϵ��ʵ���������Token
//	ofstream Tokenf("token.txt",ios::out);
	scanner(SNLf,SNLE);
	//�ڿ���̨��ʾtoken 
	for(int i=0;i<token.t.size();++i){
		tokenf<<token.t[i]<<endl;
	}
	ifstream input("predict.txt",ios::in);
	Predict predict(input);
	//�﷨���� 
	recurseParsing(predict); 
	return 0;
}

//
void recurseParsing(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,0)){	
		ProgramHead(predict);
		DeclarePart(predict);
		ProgramBody(predict);
		cout<<"�﷨�����ɹ���"<<endl;
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}

void ProgramHead(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,1)){	
		token.Match(t,"PROGRAM");
		ProgramName(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}

void ProgramName(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,2)){	
		token.Match(t,"ID");
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void DeclarePart(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,3)){	
		TypeDecpart(predict);
		VarDecpart(predict);
		ProcDecpart(predict); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}

void TypeDecpart(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,4)){	
		return;
	}
	else if(predict.isGenerated(t,5)){
		TypeDec(predict);
	} 
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void TypeDec(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,6)){	
		token.Match(t,"TYPE");
		TypeDecList(predict); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1); 
	}
}
void TypeDecList(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,7)){	
		TypeId(predict);
		t = token.getToken();
		token.Match(t,"=");
		TypeDef(predict);
		t = token.getToken();
		token.Match(t,";");
		TypeDecMore(predict); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1); 
	}
}
void TypeId(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,10)){	
		token.Match(t,"ID");
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1); 
	}
}
void TypeDef(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,11)){	
		BaseType(predict);
	}
	else if(predict.isGenerated(t,12)){
		StructureType(predict); 
	}
	else if(predict.isGenerated(t,13)){
		token.Match(t,"ID");
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1); 
	}
}
void TypeDecMore(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,8)){	
		return;
	}
	else if(predict.isGenerated(t,9)){
		TypeDecList(predict); 
	} 
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void BaseType(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,14)){	
		token.Match(t,"INTEGER");
	}
	else if(predict.isGenerated(t,15)){
		token.Match(t,"CHAR");
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void StructureType(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,16)){	
		ArrayType(predict);
	}
	else if(predict.isGenerated(t,17)){
		RecType(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void ArrayType(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,18)){	
		token.Match(t,"ARRAY");
		t = token.getToken();
		token.Match(t,"[");
		Low(predict);
		t = token.getToken();
		token.Match(t,"..");
		Top(predict);
		t = token.getToken();
		token.Match(t,"]");
		t = token.getToken();
		token.Match(t,"OF");
		BaseType(predict); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1); 
	}
}
void Low(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,19)){
		token.Match(t,"INTC");
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void Top(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,20)){
		token.Match(t,"INTC");
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void RecType(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,21)){
		token.Match(t,"RECORD");
		FieldDecList(predict);
		t = token.getToken();
		token.Match(t,"END"); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void FieldDecList(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,22)){
		BaseType(predict);
		IdList(predict);
		t = token.getToken();
		token.Match(t,";");
		FieldDecMore(predict); 
	}
	else if(predict.isGenerated(t,23)){
		ArrayType(predict);
		IdList(predict);
		t = token.getToken();
		token.Match(t,";");
		FieldDecMore(predict); 
	} 
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void FieldDecMore(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,24)){
		return; 
	}
	else if(predict.isGenerated(t,25)){
		FieldDecList(predict); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void IdList(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,26)){
		token.Match(t,"ID");
		IdMore(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void IdMore(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,27)){
		return;
	}
	else if(predict.isGenerated(t,28)){
		token.Match(t,",");
		IdList(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1); 
	}
}
void VarDecpart(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,29)){
		return;
	}
	else if(predict.isGenerated(t,30)){
		VarDec(predict);
	} 
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void VarDec(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,31)){
		token.Match(t,"VAR");
		VarDecList(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void VarDecList(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,32)){
		TypeDef(predict);
		VarIdList(predict);
		t = token.getToken();
		token.Match(t,";");
		VarDecMore(predict); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1); 
	}
}
void VarDecMore(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,33)){
		return;
	}
	else if(predict.isGenerated(t,34)){
		VarDecList(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1); 
	}
}
void VarIdList(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,35)){
		token.Match(t,"ID");
		VarIdMore(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void VarIdMore(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,36)){
		return;
	}
	else if(predict.isGenerated(t,37)){
		token.Match(t,",");
		VarIdList(predict); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void ProcDecpart(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,38)){
		return;
	}
	else if(predict.isGenerated(t,39)){
		ProcDec(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1); 
	}
}
void ProcDec(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,40)){
		token.Match(t,"PROCEDURE");
		ProcName(predict);
		t = token.getToken();
		token.Match(t,"(");
		ParamList(predict);
		t = token.getToken();
		token.Match(t,")");
		t = token.getToken();
		token.Match(t,";");
		ProcDecPart(predict);
		ProcBody(predict);
		ProcDecMore(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1); 
	}
}
void ProcDecMore(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,41)){
		return;
	}
	else if(predict.isGenerated(t,42)){
		ProcDec(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void ProcName(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,43)){
		token.Match(t,"ID");
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void ParamList(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,44)){
		return;
	}
	else if(predict.isGenerated(t,45)){
		ParamDecList(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void ParamDecList(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,46)){
		Param(predict);
		ParamMore(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1); 
	}
}
void ParamMore(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,47)){
		return;
	}
	else if(predict.isGenerated(t,48)){
		token.Match(t,";");
		ParamDecList(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1); 
	}
}
void Param(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,49)){
		TypeDef(predict);
		FormList(predict); 
	}
	else if(predict.isGenerated(t,50)){
		token.Match(t,"VAR");
		TypeDef(predict);
		FormList(predict); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void FormList(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,51)){
		token.Match(t,"ID");
		FidMore(predict); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}

void FidMore(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,52)){
		return;
	}
	else if(predict.isGenerated(t,53)){
		token.Match(t,",");
		FormList(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void ProcDecPart(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,54)){
		DeclarePart(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}

void ProcBody(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,55)){
		ProgramBody(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void ProgramBody(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,56)){	
		token.Match(t,"BEGIN");
		StmList(predict);
		t = token.getToken();
		token.Match(t,"END"); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void StmList(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,57)){
		Stm(predict);
		StmMore(predict); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1); 
	}
}
void StmMore(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,58)){
		return;
	}
	else if(predict.isGenerated(t,59)){
		token.Match(t,";");
		StmList(predict); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void Stm(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,60)){
		ConditionalStm(predict);
	}
	else if(predict.isGenerated(t,61)){
		LoopStm(predict);
	}
	else if(predict.isGenerated(t,62)){
		InputStm(predict);
	}
	else if(predict.isGenerated(t,63)){
		OutputStm(predict); 
	}
	else if(predict.isGenerated(t,64)){
		ReturnStm(predict); 
	}
	else if(predict.isGenerated(t,65)){
		token.Match(t,"ID");
		AssCall(predict); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void AssCall(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,66)){
		AssignmentRest(predict); 
	}
	else if(predict.isGenerated(t,67)){
		CallStmRest(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void AssignmentRest(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,68)){
		VariMore(predict);
		t = token.getToken();
		token.Match(t,":=");
		Exp(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void ConditionalStm(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,69)){
		token.Match(t,"IF");
		RelExp(predict);
		t = token.getToken();
		token.Match(t,"THEN");
		StmList(predict);
		t = token.getToken();
		token.Match(t,"ELSE");
		StmList(predict);
		t = token.getToken();
		token.Match(t,"FI"); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void LoopStm(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,70)){
		token.Match(t,"WHILE");
		RelExp(predict);
		t = token.getToken();
		token.Match(t,"DO");
		StmList(predict);
		t = token.getToken();
		token.Match(t,"ENDWH");
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void InputStm(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,71)){
		token.Match(t,"READ");
		t = token.getToken();
		token.Match(t,"(");
		Invar(predict);
		t = token.getToken();
		token.Match(t,")"); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void Invar(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,72)){
		token.Match(t,"ID");
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void OutputStm(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,73)){
		token.Match(t,"WRITE");
		t = token.getToken();
		token.Match(t,"(");
		Exp(predict);
		t = token.getToken();
		token.Match(t,")"); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void ReturnStm(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,74)){
		token.Match(t,"RETURN");
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void CallStmRest(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,75)){
		token.Match(t,"(");
		ActParamList(predict);
		t = token.getToken();
		token.Match(t,")"); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1); 
	}
}
void ActParamList(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,76)){
		return;
	}
	else if(predict.isGenerated(t,77)){
		Exp(predict);
		ActParamMore(predict); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void ActParamMore(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,78)){
		return;
	}
	else if(predict.isGenerated(t,79)){
		token.Match(t,",");
		ActParamList(predict); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void RelExp(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,80)){
		Exp(predict);
		OtherRelE(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void OtherRelE(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,81)){
		CmpOp(predict);
		Exp(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void Exp(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,82)){
		Term(predict);
		OtherTerm(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void OtherTerm(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,83)){
		return;
	}
	else if(predict.isGenerated(t,84)){
		AddOp(predict);
		Exp(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void Term(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,85)){
		Factor(predict);
		OtherFactor(predict); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void OtherFactor(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,86)){
		return;
	}
	else if(predict.isGenerated(t,87)){
		MultOp(predict);
		Term(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void Factor(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,88)){
		token.Match(t,"(");
		Exp(predict);
		t = token.getToken();
		token.Match(t,")");
	}
	else if(predict.isGenerated(t,89)){
		token.Match(t,"INTC");
	}
	else if(predict.isGenerated(t,90)){
		Variable(predict); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void Variable(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,91)){
		token.Match(t,"ID");
		VariMore(predict); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1); 
	}
}
void VariMore(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,92)){
		return;
	}
	else if(predict.isGenerated(t,93)){
		token.Match(t,"[");
		Exp(predict);
		t = token.getToken();
		token.Match(t,"]"); 
	}
	else if(predict.isGenerated(t,94)){
		token.Match(t,".");
		FieldVar(predict);
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void FieldVar(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,95)){
		token.Match(t,"ID");
		FieldVarMore(predict); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void FieldVarMore(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,96)){
		return;
	}
	else if(predict.isGenerated(t,97)){
		token.Match(t,"[");
		Exp(predict);
		t = token.getToken();
		token.Match(t,"]"); 
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void CmpOp(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,98)){
		token.Match(t,"<");
	}
	else if(predict.isGenerated(t,99)){
		token.Match(t,"=");
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void AddOp(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,100)){
		token.Match(t,"+");
	}
	else if(predict.isGenerated(t,101)){
		token.Match(t,"-");
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
void MultOp(Predict& predict)
{
	string t = token.getToken();
	if(predict.isGenerated(t,102)){
		token.Match(t,"*");
	}
	else if(predict.isGenerated(t,103)){
		token.Match(t,"/");
	}
	else{
		errorHandle(SNLE,parseline,parselineword,1);
	}
}
//�ӱ���ļ�������������token���з���token���û�ŵ��ļ��� 
void scanner(ifstream& input,ofstream& SNLE)
{
	//��δ��ļ��ж�ȡ���ݣ��Ƕ�ȡһ��String����һ��һ����ȡ�ַ�
	//����x:=5+1;�����һ����ֵ��䣬����Ӧ�ð������һ��һ�����ʣ�����Ӧ��һ��һ���ַ���ȡ
	//ʹ��c ������peekһ��һ���ַ� 
	string word;
	char c;
	State restart = rs;
	State s;
	Edge e;
	int scanLine = 1;
	int linewordnum = 1;
	bool eop = false;
	for(int i = 0; !input.eof(); ++i){
		//ÿһ�����ʴ�״̬S0��ʼ����ʼȡһ�����ǿո����\n���ַ� 
		word.clear();
		s = s0;
		c = input.peek();
		while(c==' '||c=='\n'){
			//������ͳ������ 
			if(c=='\n'){
				++scanLine;
				token.push_back("\n");
				linewordnum = 1;
			}
			c = input.get();
			c = input.peek();
		}
		e = getEdge(c);    //���������ַ��������״̬ͼ������ߣ��������ַ�a,��ת����enum Edge�����letter 
		while(T[s][e]!=restart&&T[s][e]!=err){
			s = T[s][e];
			input.get();
			word += c;
			c = input.peek();
			//������� { ������Ҫ���⴦�������û����������һ���ַ������������ 
			if(c!='{'){
				
				//����ǳ�������ı�־'#'��
				if(c=='#'){
					input.get();
					c = input.peek();
					while(c==' '||c=='\n'){
						c = input.get();
					}
					if(c!=EOF){
						//�������� 
						errorHandle(SNLE,scanLine,linewordnum,2);
					} 
					else{
						eop = true;
						cout<<"program.txt�ļ����SNL����Դ�����ļ��ʷ������ɹ�������Token���е�token.txt"<<endl; 
					} 
				}
				e = getEdge(c);
			} 
			else{
				break; 
			} 
		}
		if(T[s][e]==err){
			//�������� 
			errorHandle(SNLE,scanLine,linewordnum,0);
		}
		else{
			//ʣ�����Ϊ������peek�����ַ�Ϊ '\n' '{' ��restart״̬
			//�����������{Ҫ���⴦������������ʾʶ��һ�����ʣ�������Ҫ������з�������Token
//			cout<<word<<endl; 
			//�������{ ע�� 
			if(c=='{'){
				c = input.get();
				c = input.peek();
				while(c!='}'){
					input.get();
					if(c=='\n'){
						++scanLine; 
						continue;
					} 
					if(c==EOF){
						//�������� 
						errorHandle(SNLE,scanLine,linewordnum,3);
					} 
				}
				continue;
			} 
			
			//������һ��token���ɣ����ǰ�һ�еĵ�������1  
			++linewordnum;
			
			//���ȱ�ʶ���ͱ�������Ҫ����
			if(s==s1){
				if(reservedtable.find(word)){
//					cout<<word<<" is "<<"reserved word"<<endl; 
					token.push_back(word);
				}
				else{
//					cout<<word<<" is "<<"an ID"<<endl; 
					token.push_back("ID");
				} 
			} 
			else if(s==s2){
				 token.push_back("INTC");
			}
			else if(s==s3){
				token.push_back(word);
			}
			else if(s==s5){
				token.push_back(word);
			}
			else if(s==s8){
				token.push_back("CHARC");
			} 
			else if(s==s9){
				token.push_back(word);
			} 
			else if(s==s10){
				token.push_back(word);
			} 
		}
	}
	if(eop==false){
		errorHandle(SNLE,scanLine,linewordnum,2);
	} 
}

string toString(int num)
{
	int num_ = num;
	char c = '0';
	string s;
	while(num_){
		c += num_%10;
		num_ /= 10;
		s += c;
	}
	return s;
}
//mod�����������0�ʷ�����  1�﷨����
//                 2#����Ҳ���ǳ��������ʶ������  3ע�ʹ��� 
                      
void errorHandle(ofstream& errf,int line,int wordnum,int mod)
{
	if(mod==0){
		errf<<"��"<<line<<"�е�"<<wordnum<<"�������дʷ�����\n"; 
	}
	if(mod==1){
		errf<<"��"<<line<<"�е�"<<wordnum<<"���������﷨����\n"; 
	}
	if(mod==2){
		errf<<"���������ʶ�����д���\n";
	} 
	if(mod==3){
		errf<<"��"<<line<<"�е�ע��������\n";
	}
	cout<<"��"<<line<<"�е�"<<wordnum<<"�����ʳ�����"<<endl; 
	errf.close(); 
	system("Pause");
	exit(0);
}

bool isSingleDelimit(const char& c)
{
	//���ַֽڷ� + , - , * , / , < ,= ,( , ) , [ , ] , . , ; , EOF ,�հ��ַ� ��������©���˶��� 
	//Ҫ�������һ���ַ��������. �ж��� . ���� .. ������, ���ǾͰѵ��ַ��ֽڷ���ȥ��'.'������ʼ״̬S0����'.'��ת��S6״̬
	//����ȥ����Ҫ����һ���ַ��������ж��ǵ��ַ��ֽڷ����������±���޷�
	//���� = ���⣬��Ϊ:=������Ҫ��������=��������״̬ת������������Ҫ��=�ӵ��ַֽڷ���ȥ�� 
	if(c=='+'||c=='-'||c=='*'||c=='/'||c=='<'||c=='('||c==')'||c=='['||c==']'||c==';'||c==' '||c==','||c=='\n'){
		return true;
	}
	return false;
}
Edge getEdge(char& c)
{
	//isalpha��ͷ�ļ�<ctype.h>���� �����ж��Ƿ�����ĸ,isdigitͬ�� 
	if(isalpha(c)){
		return letter;
	}
	if(isdigit(c)){
		return digit;
	}
	if(isSingleDelimit(c)){
		return sdl;
	}
	if(c==':'){
		return colon;
	}
	if(c=='='){
		return eq;
	}
	if(c=='\''){
		return squotes;
	}
	if(c=='.'){
		return dot;
	}
	return other;
}

